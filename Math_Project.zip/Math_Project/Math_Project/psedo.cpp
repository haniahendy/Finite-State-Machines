//pseudocode
enum ElevatorState {
    INACTIVE,
    MOVING_UP,
    MOVING_DOWN,
    DOOR_OPEN
}

// Define the Elevator class
class Elevator {
    ElevatorState currentState
        int currentFloor

        // Constructor
        Elevator() :
        currentState = INACTIVE,
        currentFloor = 0

        // Method to handle floor requests
        method requestFloor(floor) :
        if currentState == INACTIVE :
            moveElevator(floor)
        else :
            print "Elevator is busy. Please wait."

            // Method to move the elevator to a specified floor
            method moveElevator(floor) :
            if floor > currentFloor:
    currentState = MOVING_UP
        print "Elevator is moving up."
        for i from currentFloor to floor :
    wait(1)  // Time to move between floors
        currentFloor++
        print "Current floor: " + currentFloor
            else if floor < currentFloor:
    currentState = MOVING_DOWN
        print "Elevator is moving down."
        for i from currentFloor to floor :
    wait(1)  // Time to move between floors
        currentFloor--
        print "Current floor: " + currentFloor

        currentState = DOOR_OPEN
        print "Elevator has arrived at floor " + currentFloor + "."
        wait(2)  // Time to open the door

        currentState = INACTIVE
        print "Elevator door is closed. Elevator is now idle."
};