using namespace std;
#include <iostream>
#include <thread>
#include <chrono>

enum class ElevatorState {
    inactive,
    MovingUp,
    MovingDown,
    DoorOpen
};

class Elevator {
public:
    Elevator() : currentState(ElevatorState::inactive), currentFloor(0) {}

    void requestFloor(int floor) {
        if (currentState == ElevatorState::inactive) {
            moveElevator(floor);
        }
        else {
            cout << "Elevator is busy. Please wait." << endl;
        }
    }

private:
    void moveElevator(int floor) {
        if (floor > currentFloor) {
            currentState = ElevatorState::MovingUp;
            cout << "Elevator is moving up." << endl;
            for (int i = currentFloor; i < floor; ++i) {
                this_thread::sleep_for(chrono::seconds(1));  // Time to move between floors
                currentFloor++;
                cout << "Current floor: " << currentFloor << endl;
            }
        }
        else if (floor < currentFloor) {
            currentState = ElevatorState::MovingDown;
            cout << "Elevator is moving down." << endl;
            for (int i = currentFloor; i > floor; --i) {
                this_thread::sleep_for(chrono::seconds(1));  // Time to move between floors
                currentFloor--;
                cout << "Current floor: " << currentFloor << endl;
            }
        }

        currentState = ElevatorState::DoorOpen;
        cout << "Elevator has arrived at floor " << currentFloor << "." << endl;
        this_thread::sleep_for(chrono::seconds(2));  // Time to open the door

        currentState = ElevatorState::inactive;
        cout << "Elevator door is closed. Elevator is now idle." << endl;
    }

    ElevatorState currentState;
    int currentFloor;
};

int main() {
    Elevator elevator;

    elevator.requestFloor(3);
    elevator.requestFloor(1);
    elevator.requestFloor(5);

    return 0;
}